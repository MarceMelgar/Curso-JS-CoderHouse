/* let nombre = "Juan"
let apellido = 'Gomez'
let edad = 20
let alturaEnMetros = 1.87

console.log(nombre)
nombre = "Pedro"
console.log(edad)
console.log(nombre + " " + apellido)

let resultado = edad + 5
console.log(resultado) */

/* let nombre = prompt("Ingrese nombre")
let apellido = prompt("Ingrese apellido")

alert("Bienvenido " + nombre + " " + apellido)

let salida = nombre + " " + apellido
console.log(salida) */

/* let edad = parseInt(prompt("Ingrese su edad"))
console.log(edad + 10) */

let nombre = prompt("Ingrese nombre")
console.log(nombre.length)







